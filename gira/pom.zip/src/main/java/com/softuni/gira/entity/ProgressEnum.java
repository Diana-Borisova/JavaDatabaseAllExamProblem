package com.softuni.gira.entity;

import lombok.Getter;

@Getter
public enum ProgressEnum {
    OPEN, IN_PROGRESS, COMPLETED, OTHER;
}
