package com.softuni.gira.entity;

import lombok.Getter;

@Getter
public enum ClassificationEnum {

    BUG, FEATURE, SUPPORT, OTHER;
}
