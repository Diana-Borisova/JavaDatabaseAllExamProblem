package softuni.exam.models.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Email;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "cars")
public class Car extends BaseEntity{
    @Enumerated(EnumType.STRING)
    @Column(name = "car_type",nullable = false)
    private CarType carType;

    @Size(min = 2, max = 30)
    @Column(nullable = false)
    private String carMake;

    @Size(min = 2, max = 30)
    @Column(nullable = false)
    private String carModel;

    @Positive
    @Column( nullable = false)
    private int year;

    @Size(min = 2, max = 30)
    @Column(unique = true, nullable = false)
    private String plateNumber;

    @Positive
    @Column( nullable = false)
    private int	kilometers;

    @DecimalMin("1.00")
    @Column(nullable = false)
    private Double engine;


    @OneToMany(mappedBy = "car")
    private List<Task> tasks;
}
