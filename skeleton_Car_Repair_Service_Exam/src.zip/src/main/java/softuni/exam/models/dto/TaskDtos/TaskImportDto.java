package softuni.exam.models.dto.TaskDtos;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.xml.bind.annotation.*;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@XmlRootElement(name = "task")
@XmlAccessorType(XmlAccessType.FIELD)
public class TaskImportDto {

    @NonNull
    @XmlElement
    private String date;

    @Positive
    @NonNull
    @XmlElement
    private BigDecimal price;

    @NonNull
    @XmlAttribute(name = "car")
    private CarXmlImportDto car;


    @NonNull
    @XmlElement(name = "firstName")
    private MechanicXmlImportDto firstName;

    @NonNull
    @XmlAttribute(name = "part")
    private PartXMLImportDto part;


    @NonNull
    @XmlElement(name = "lastName")
    private MechanicLastNameImportDto lastName;

}
